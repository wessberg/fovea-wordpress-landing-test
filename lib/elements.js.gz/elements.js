var _Mathabs=Math.abs,_Mathmax=Math.max;(function(n){"use strict";function o(Ae,Oe,Re,we){var Se,ve=arguments.length,be=3>ve?Oe:null===we?we=Object.getOwnPropertyDescriptor(Oe,Re):we;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)be=Reflect.decorate(Ae,Oe,Re,we);else for(var Te=Ae.length-1;0<=Te;Te--)(Se=Ae[Te])&&(be=(3>ve?Se(be):3<ve?Se(Oe,Re,be):Se(Oe,Re))||be);return 3<ve&&be&&Object.defineProperty(Oe,Re,be),be}function a(Ae){return(Oe)=>{customElements.define(Ae,Oe);const Re=Oe.styles(),we=Oe.markup();if(null!=Re||null!=we){const ve=null==Re?"":`
		<link rel="stylesheet" href="${WP.templateUrl}/shared.css?ver=${WP.version}" />
		<style>${Re}</style>`,be=null==we?"":we,Se=document.createElement("template");Se.innerHTML=`
		${ve}
		${be}
	`,Oe.template=Se}}}class l{static addIcon(Ae){l.seenIcons.set(Ae.selector,Ae)}static addIcons(Ae){Ae.map((Oe)=>this.addIcon(Oe))}buildIconFromName(Ae){const Oe=l.seenIcons.get(Ae);if(null==Oe)throw new ReferenceError(`No icon was found for selector: ${Ae}`);return this.buildSvgIcon(Oe)}buildSvgIcon(Ae){const Oe=document.createElementNS("http://www.w3.org/2000/svg","svg"),Re=document.createElementNS("http://www.w3.org/2000/svg","g");return Re.innerHTML=Ae.template,Re.setAttribute("viewBox",Ae.viewBox),Oe.setAttribute("viewBox",Ae.viewBox),Oe.setAttribute("preserveAspectRatio","xMidYMid meet"),Oe.style.cssText="pointer-events: none; display: block; width: 100%; height: 100%;",Oe.appendChild(Re),Oe}}l.seenIcons=new Map;const s={selector:"fovea-tiny",viewBox:"0 0 61 61",template:`<defs><circle id="path-1" cx="30.5" cy="30.5" r="30.5"/></defs><g id="Page-2" fill="none" fill-rule="evenodd"><g id="tiny_icon"><mask id="mask-2" fill="#fff"><use xlink:href="#path-1"/></mask><use id="rounding_mask" fill="#D8D8D8" xlink:href="#path-1"/><path id="fill_target" mask="url(#mask-2)" d="M0 0h61v61H0z"/><g id="chip" mask="url(#mask-2)" fill="#FFF"><path d="M22.06 18.3h17.5v1.52h4.36v3.05h-4.37v3.05h4.37v3.05h-4.37v3.06h4.37v3.04h-4.37v3.05h4.37v3.06h-4.37v1.52h-17.5v-1.53H17.7v-3.05h4.36v-3.04H17.7v-3.05h4.36v-3.05H17.7v-3.05h4.36v-3.05H17.7v-3.05h4.36V18.3zm7.3 16.77v4.58h1.45v-4.57h-1.44zm2.9 0v4.58h1.46v-4.57h-1.46zm2.92 0v4.58h1.45v-4.57h-1.45z" id="Shape"/></g><path id="bg_overlay" fill="#000" opacity=".07" mask="url(#mask-2)" d="M0 0h61v30.5H0z"/></g></g>`},u={selector:"fovea-fast",viewBox:"0 0 61 61",template:`<defs><circle id="path-1" cx="30.5" cy="30.5" r="30.5"/></defs><g id="Page-2" fill="none" fill-rule="evenodd"><g id="rounded_icon"><mask id="mask-2" fill="#fff"><use xlink:href="#path-1"/></mask><use id="rounding_mask" fill="#D8D8D8" xlink:href="#path-1"/><path id="fill_target" mask="url(#mask-2)" d="M0 0h61v61H0z"/><g id="logo" mask="url(#mask-2)" fill-rule="nonzero" fill="#FFF"><path d="M46.97 30.5c0 6.4-5.26 11.6-11.76 11.6-6.44 0-11.7-5.2-11.7-11.6 0-6.4 5.26-11.6 11.75-11.6 6.5 0 11.77 5.2 11.77 11.6zm-11.02-5.8h-2.2v6.38l4.06 4 1.6-1.52-3.4-3.38V24.7zM14.88 39.2c-.8 0-1.47-.66-1.47-1.46 0-.8.7-1.45 1.5-1.45h6.88c.45 1 1.04 2 1.72 2.9h-8.6zm-1.7-7.25c-.82 0-1.48-.65-1.48-1.45 0-.8.66-1.45 1.47-1.45h7.42l-.1 1.45.05 1.45h-7.42zm-1.4-7.25c-.82 0-1.48-.64-1.48-1.44 0-.8.66-1.45 1.47-1.45h11.7c-.7.9-1.28 1.9-1.73 2.9h-9.97z" id="Shape"/></g><path id="bg_overlay" fill="#000" opacity=".07" mask="url(#mask-2)" d="M0 0h61v30.5H0z"/></g></g>`},f={selector:"fovea-intuitive",viewBox:"0 0 61 61",template:`<defs><circle id="path-1" cx="30.5" cy="30.5" r="30.5"/></defs><g id="Page-2" fill="none" fill-rule="evenodd"><g id="intuitive_icon"><mask id="mask-2" fill="#fff"><use xlink:href="#path-1"/></mask><use id="rounding_mask" fill="#D8D8D8" xlink:href="#path-1"/><path id="fill_target" mask="url(#mask-2)" d="M0 0h61v61H0z"/><g id="web-components" mask="url(#mask-2)"><g fill-rule="nonzero" id="Group"><path id="Shape" fill-opacity=".68" fill="#FEC007" d="M21.97 47.96L11.77 19.9l28.04-7.53L45 41.8l-10.64 6.28-12.3-.12"/><path id="Shape" fill-opacity=".77" fill="#FEC007" d="M42.24 40.55L37.88 15.4 26.4 18.5l7.24 27.13z"/><path d="M53.16 26.88l1.3 4.52-10 2.84s0 6.04-4.86 8.44c-4.86 2.4-8.63.37-8.63.37l-.6-1.75 7.2-1.97 1.6-6.2-4.65-4.57-6.67 2.03-.58-1.6s3.13-7 12.33-3c0 0 2.9 1.8 3.55 3.4l10-2.6zm1.3-.33l1.6-.47 1.28 4.6-1.67.52-1.2-4.65z" id="Shape" fill="#FFF"/><path d="M55.02 26.34l1.04-.26 1.28 4.6-1.67.52-.44-1.54.67-.26-.88-3.06zm-2.97.83l1.1-.3 1.3 4.53-10 2.84s-.1 5.27-3.6 7.66c-3.46 2.38-7.38 2.3-9.88 1.15l-.28-.8s6.8 1.6 10.1-3.54c2-3.3 2-5.8 2-5.8l10-2.7-.87-3zM27.27 29l5.87-1.72 1.38 1.28-6.67 2.03-.58-1.6z" id="Shape" fill="#FEC007"/><path d="M6.56 32.2l1.18 4.54 10.04-2.7s3.08 5.2 8.48 4.76c5.4-.43 7.6-4.12 7.6-4.12l-.37-1.8-7.2 2-4.6-4.5 1.62-6.32 6.76-1.68-.3-1.67s-6.2-4.3-12.1 3.8c0 0-1.6 3.1-1.3 4.8l-9.9 3zm-1.3.38l-1.6.42 1.25 4.62 1.7-.42-1.3-4.62z" id="Shape" fill="#FFF"/><path d="M4.68 32.7l-1.02.3 1.25 4.62 1.7-.42-.4-1.55-.7.1-.8-3.06zm2.98-.83l-1.1.33 1.18 4.54 10.04-2.7s2.78 4.48 7 4.74c4.2.26 7.53-1.8 9.08-4.1l-.17-.83s-5.1 4.87-10.6 2.2c-3.5-1.87-4.7-3.98-4.7-3.98l-10 2.8-.8-3zm22.22-11.15l-5.92 1.54-.53 1.8 6.76-1.68-.4-1.66z" id="Shape" fill="#FEC007"/></g></g><path id="bg_overlay" fill="#000" opacity=".07" mask="url(#mask-2)" d="M0 0h61v30.5H0z"/></g></g>`},p={selector:"fovea-logo",viewBox:"0 0 123 197",template:`<g fill-rule="evenodd"><path opacity=".7" d="M61.2 46l60.6 52-60.6 46L0 98"/><path opacity=".8" d="M62 23.3l60.5 52.2-60.6 46-61.4-46"/><path d="M61.2 0l60.6 52-60.6 46L0 52"/><path opacity=".8" d="M0 98l61.2 46v52.2L0 149"/><path d="M121.8 98l-60.6 46v52.2c20.2-16 60.6-47.3 60.6-47.3V98z"/></g>`},g={selector:"fovea-1",viewBox:"0 0 74 74",template:`<path fill-rule="evenodd" d="M37 74C16.6 74 0 57.4 0 37S16.6 0 37 0s37 16.6 37 37-16.6 37-37 37zm2-24V26.5l-8 1v2.2h4.8V50H39z"/>`},m={selector:"fovea-2",viewBox:"0 0 74 74",template:`<path fill-rule="evenodd" d="M37 74C16.6 74 0 57.4 0 37S16.6 0 37 0s37 16.6 37 37-16.6 37-37 37zm8-24v-2.5H34l6.2-6.8c1.3-1.5 2.4-2.8 3.2-4 .7-1.4 1-2.7 1-4 0-2-.5-3.4-1.8-4.7-1.2-1.2-3-1.8-5-1.8-2.5 0-4.4.7-5.8 2-1.4 1.4-2 3-2 5.2h3c0-1.5.4-2.6 1.2-3.5.8-1 2-1.6 3.6-1.6 1 0 2 .4 2.7 1.2.8.7 1 1.7 1 3 0 .8 0 1.7-.6 2.6-.5 1-1.4 2-2.8 3.7l-8 9v2h15z"/>`},E={selector:"rollup-logo",viewBox:"0 0 56 73",template:`<defs><linearGradient id="a" x1="26.8%" x2="67.6%" y1="48.2%" y2="55.3%"><stop stop-color="#FF6533" offset="0%"/><stop stop-color="#FF5633" offset="15.7%"/><stop stop-color="#FF4333" offset="43.4%"/><stop stop-color="#FF3733" offset="71.4%"/><stop stop-color="#F33" offset="100%"/></linearGradient><linearGradient id="b" x1="20.5%" x2="93.5%" y1="38.1%" y2="80.4%"><stop stop-color="#BF3338" offset="0%"/><stop stop-color="#F33" offset="100%"/></linearGradient><linearGradient id="c" x1="32.3%" x2="45.6%" y1="39.5%" y2="48.9%"><stop stop-color="#FF6533" offset="0%"/><stop stop-color="#FF5633" offset="15.7%"/><stop stop-color="#FF4333" offset="43.4%"/><stop stop-color="#FF3733" offset="71.4%"/><stop stop-color="#F33" offset="100%"/></linearGradient><linearGradient id="d" x1="51.6%" x2="48.5%" y1="78.3%" y2="41.7%"><stop stop-color="#FF6533" offset="0%"/><stop stop-color="#FF5633" offset="15.7%"/><stop stop-color="#FF4333" offset="43.4%"/><stop stop-color="#FF3733" offset="71.4%"/><stop stop-color="#F33" offset="100%"/></linearGradient><linearGradient id="e" x1="40.2%" x2="54%" y1="47.2%" y2="54.5%"><stop stop-color="#FBB040" offset="0%"/><stop stop-color="#FB8840" offset="100%"/></linearGradient><linearGradient id="f" x1="55.2%" x2="40.9%" y1="5.9%" y2="128%"><stop stop-color="#FFF" offset="0%"/><stop stop-color="#FFF" stop-opacity="0" offset="100%"/></linearGradient></defs><g fill="none"><path fill="url(#a)" d="M48 16.4C48 12 47 8 45 4.6 39.8-1 28.4-2 25.6 4.6c-3 6.7 4.8 14.3 8.2 13.7 4.4-.8-.7-10.7-.7-10.7 7 12.5 5.5 8.6-6.5 20.2C14.5 39.3 2 63.5.5 64.6H0h47c.7 0 1.3-.8 1-1.5L35.5 39c-.2-.6 0-1.2.5-1.5 7.2-4 12-12 12-20.8z" transform="translate(7.505 7.67)"/><path fill="url(#b)" d="M48 16.4C48 12 47 8 45 4.6 39.8-1 28.4-2 25.6 4.6c-3 6.7 4.8 14.3 8.2 13.7 4.4-.8-.7-10.7-.7-10.7 7 12.5 5.5 8.6-6.5 20.2C14.5 39.3 2 63.5.5 64.6H0h47c.7 0 1.3-.8 1-1.5L35.5 39c-.2-.6 0-1.2.5-1.5 7.2-4 12-12 12-20.8z" transform="translate(7.505 7.67)"/><path fill="url(#c)" d="M7.8 72.2c1.7-1 14-25.3 26-36.8 12-11.5 13.4-7.7 6.8-20.2 0 0-25.3 35.7-34.5 53.3"/><path fill="url(#d)" d="M9.4 40.3C26.4 8.7 28.7 5.5 37.7 5.5c4.6 0 9.4 2 12.4 6C46 4.5 39 0 30 0H1C.6 0 0 .5 0 1v59c1.7-4.5 4.7-11 9.4-19.7z" transform="translate(1.908)"/><path fill="url(#e)" d="M33.7 35.4C21.7 47 9.5 71.2 7.7 72.2c-1.7 1-4.7 1.2-6.3-.6-1.7-2-4.3-5 10-31.3 17-31.6 19.2-34.8 28-34.8 4.7 0 9.5 2 12.5 6l.2.7c-5-5.4-16.4-6.6-19.4 0C30 19 38 26.6 41.3 26c4.3-.8-.8-10.8-.8-10.8 6.6 12.5 5 8.7-7 20.2z"/><path fill="url(#f)" d="M12.7 41.7C29.7 10 32 7 41 7c3.8 0 7.7 1.3 10.6 4-3-3.5-7.5-5.5-12-5.5-9 0-11.2 3.2-28.3 34.8C-3 66.6-.3 69.7 1.3 71.6l1 .7C.6 70 0 65 12.6 41.7z" opacity=".3"/></g>`},I={selector:"webpack-logo",viewBox:"0 0 67 78",template:`<g fill="none"><path fill="#A2BDE9" d="M33.5 0L0 19.6v38.8l33.5 19.4L67 58.3V19.5"/><path fill="#6F95DB" d="M33.5 19.8L17 29.4v19.3l16.5 9.6L50 48.7V29.4"/><path fill="#FFF" d="M33.5 0L0 19.5 33.5 38 67 19.6M33.5 40.4L0 58.4l33.5 19.3L67 58" opacity=".1"/></g>`},A={selector:"typescript-logo",viewBox:"0 0 284 70",template:`<path fill="#007ACC" d="M34.98 7.56H20.43v45.07h-5.9V7.56H0V2.2h34.98v5.36zm22.96 9.07L41.38 58.4c-2.95 7.44-7.1 11.17-12.45 11.17-1.5 0-2.75-.15-3.76-.46V64c1.24.42 2.38.63 3.4.63 2.92 0 5.1-1.73 6.55-5.2L38 52.55l-14.06-35.9h6.4l9.74 27.7c.12.34.36 1.26.74 2.73h.2c.13-.56.36-1.45.7-2.67l10.24-27.7h5.98zm9.43 30.8h-.14V69.2h-5.77V16.62h5.77v6.33h.14c2.84-4.78 6.98-7.17 12.45-7.17 4.64 0 8.26 1.6 10.86 4.82 2.6 3.22 3.9 7.54 3.9 12.96 0 6.02-1.46 10.85-4.4 14.47-2.92 3.62-6.93 5.43-12 5.43-4.68 0-8.28-2.02-10.8-6.05zm-.14-14.52V38c0 2.98.97 5.5 2.9 7.58s4.4 3.1 7.37 3.1c3.5 0 6.23-1.33 8.2-4 2-2.67 2.98-6.4 2.98-11.14 0-4-.93-7.15-2.78-9.42-1.85-2.27-4.36-3.4-7.52-3.4-3.35 0-6.05 1.16-8.1 3.5-2.03 2.3-3.05 5.23-3.05 8.75zm62.33 3.2h-25.42c.1 4 1.17 7.1 3.23 9.3 2.06 2.2 4.9 3.3 8.5 3.3 4.06 0 7.8-1.3 11.2-4V50c-3.17 2.3-7.36 3.45-12.56 3.45-5 0-9-1.63-11.9-4.9-2.9-3.27-4.3-7.87-4.3-13.8 0-5.6 1.6-10.17 4.8-13.7 3.2-3.52 7.1-5.28 11.9-5.28 4.7 0 8.4 1.5 11 4.56 2.6 3.05 3.9 7.28 3.9 12.7v3zm-5.9-4.9c-.03-3.3-.84-5.9-2.42-7.7-1.58-1.8-3.78-2.7-6.6-2.7-2.7 0-5.02 1-6.92 2.9-1.9 2-3.07 4.5-3.52 7.7h19.45zm10.94 19.4v-6.9c.73.7 1.6 1.4 2.62 1.9 1.02.6 2.1 1.1 3.22 1.5 1.13.4 2.26.7 3.4.9 1.13.2 2.18.3 3.14.3 3.32 0 5.8-.6 7.45-2 1.64-1.3 2.46-3.3 2.46-5.8 0-1.3-.3-2.5-.9-3.5-.6-1-1.3-1.9-2.3-2.7-1-.8-2.1-1.6-3.5-2.4l-4.2-2.5c-1.6-.9-3.1-1.8-4.5-2.7-1.4-.9-2.6-1.9-3.6-3-1.1-1.1-1.9-2.35-2.5-3.74-.6-1.4-.9-3.03-.9-4.9 0-2.3.4-4.3 1.3-6 .94-1.7 2.15-3.1 3.66-4.2 1.5-1.1 3.2-1.9 5.1-2.45 1.93-.55 3.9-.8 5.9-.8 4.52 0 7.83.6 9.9 1.77v6.6c-2.7-2-6.2-3.1-10.5-3.1-1.15 0-2.33.2-3.5.4-1.1.3-2.2.8-3.1 1.4-.9.6-1.6 1.4-2.2 2.4-.6 1-.86 2.17-.86 3.56 0 1.3.2 2.4.65 3.36s1.1 1.8 1.9 2.56c.87.8 1.9 1.54 3.15 2.27 1.27.7 2.7 1.5 4.3 2.3 1.68.9 3.25 1.8 4.7 2.8 1.5 1 2.8 2.1 3.9 3.3 1.1 1.2 2 2.5 2.67 3.93.65 1.46 1 3.1 1 5 0 2.48-.44 4.6-1.3 6.3-.9 1.7-2.1 3.1-3.6 4.2s-3.25 1.87-5.2 2.35c-2 .5-4.08.7-6.27.7-.75 0-1.65-.04-2.7-.2-1.1-.1-2.2-.3-3.3-.53-1.14-.23-2.2-.53-3.2-.9-1-.4-1.8-.8-2.4-1.23zm58.65.4c-2.77 1.7-6.05 2.5-9.84 2.5-5.1 0-9.2-1.6-12.4-5-3.1-3.3-4.7-7.7-4.7-13 0-5.9 1.7-10.7 5.1-14.3 3.4-3.6 8-5.4 13.6-5.4 3.2 0 6 .6 8.4 1.8v5.9c-2.6-1.8-5.5-2.8-8.6-2.8-3.7 0-6.7 1.3-9 4s-3.5 6.1-3.5 10.4c0 4.3 1.1 7.6 3.4 10 2.2 2.5 5.2 3.7 8.9 3.7 3.2 0 6.1-1 8.9-3.1V51zm22.3-28.5c-1-.7-2.45-1.1-4.35-1.1-2.46 0-4.52 1.2-6.17 3.5-1.65 2.3-2.48 5.5-2.48 9.5v18.3h-5.77v-36h5.77v7.4h.14c.8-2.5 2-4.5 3.7-5.9 1.7-1.4 3.6-2.1 5.6-2.1 1.5 0 2.6.2 3.4.5v6zm6.65-15c-1.03 0-1.9-.3-2.64-1-.73-.7-1.1-1.6-1.1-2.6 0-1.1.37-1.9 1.1-2.7.73-.7 1.6-1 2.64-1 1.05 0 1.95.4 2.7 1.1.73.7 1.1 1.6 1.1 2.7 0 1-.37 1.9-1.1 2.7-.75.7-1.65 1.1-2.7 1.1zm2.8 45.2h-5.76v-36H225v36zm9.3-5.2h-.13v21.7h-5.77V16.7h5.77V23h.14c2.9-4.8 7-7.18 12.5-7.18 4.7 0 8.3 1.6 10.9 4.8 2.6 3.24 3.9 7.56 3.9 12.98 0 6.02-1.4 10.85-4.4 14.47-2.9 3.62-6.9 5.43-12 5.43-4.6 0-8.2-2.02-10.8-6.05zm-.13-14.5v5c0 3 .97 5.5 2.9 7.6s4.4 3.1 7.37 3.1c3.5 0 6.23-1.3 8.2-4 2-2.6 2.98-6.4 2.98-11.1 0-4-.93-7.1-2.78-9.4-1.85-2.2-4.36-3.4-7.52-3.4-3.35 0-6.05 1.2-8.1 3.5-2.03 2.3-3.05 5.3-3.05 8.8zm48.93 19.4c-1.37.8-3.16 1.2-5.4 1.2-6.3 0-9.45-3.5-9.45-10.5V21.6h-6.2v-4.93h6.2v-8.8L274.02 6v10.65h9.07v4.92H274v20.28c0 2.4.4 4.14 1.23 5.17.82 1.03 2.18 1.55 4.08 1.55 1.5 0 2.7-.4 3.8-1.2v4.93z"/>`},O={selector:"material-triangle",viewBox:"0 0 100 100",template:`<path fill-rule="evenodd" d="M50 0l50 100H0"/>`},R="0 0 24 24",w={selector:"heart-fill",viewBox:R,template:`<path d="M12 21.4L10.6 20C5.4 15.4 2 12.3 2 8.5 2 5.5 4.4 3 7.5 3c1.7 0 3.4.8 4.5 2 1-1.2 2.8-2 4.5-2 3 0 5.5 2.4 5.5 5.5 0 3.8-3.4 7-8.6 11.5L12 21.4z"/>`},v={selector:"menu",viewBox:R,template:`<path d="M3,6H21V8H3V6M3,11H21V13H3V11M3,16H21V18H3V16Z" />`};var N;(function(Ae){Ae[Ae.ANDROID_STOCK=0]="ANDROID_STOCK",Ae[Ae.BLACKBERRY=1]="BLACKBERRY",Ae[Ae.CHROME=2]="CHROME",Ae[Ae.EDGE=3]="EDGE",Ae[Ae.FIREFOX=4]="FIREFOX",Ae[Ae.FIREFOX_MOBILE=5]="FIREFOX_MOBILE",Ae[Ae.IE=6]="IE",Ae[Ae.IE_MOBILE=7]="IE_MOBILE",Ae[Ae.OPERA=8]="OPERA",Ae[Ae.OPERA_MINI=9]="OPERA_MINI",Ae[Ae.OPERA_MOBILE=10]="OPERA_MOBILE",Ae[Ae.SAFARI=11]="SAFARI",Ae[Ae.SAMSUNG_INTERNET=12]="SAMSUNG_INTERNET",Ae[Ae.UC_BROWSER=13]="UC_BROWSER",Ae[Ae.UNKNOWN=14]="UNKNOWN"})(N||(N={}));var D;(function(Ae){Ae[Ae.ANDROID=0]="ANDROID",Ae[Ae.IOS=1]="IOS"})(D||(D={}));let M;const C=function(){let Ae;try{Ae=self,M="self","window"in Ae||Object.defineProperty(Ae,"window",{value:self}),"global"in Ae||Object.defineProperty(Ae,"global",{value:self}),"root"in Ae||Object.defineProperty(Ae,"root",{value:self})}catch(Oe){try{Ae=global,M="global","window"in Ae||Object.defineProperty(Ae,"window",{value:global}),"self"in Ae||Object.defineProperty(Ae,"self",{value:global}),"root"in Ae||Object.defineProperty(Ae,"root",{value:global})}catch(Re){Ae=window,M="window","global"in Ae||Object.defineProperty(Ae,"global",{value:window}),"self"in Ae||Object.defineProperty(Ae,"self",{value:window}),"root"in Ae||Object.defineProperty(Ae,"root",{value:window})}}return Ae}();const H=new class{block(Ae){window.addEventListener(Ae,(Oe)=>{Oe.preventDefault(),Oe.stopPropagation()})}},L=new class{constructor(){this.agent=null==navigator||null==navigator.userAgent?"":navigator.userAgent.toLowerCase(),this.browser=this.detectBrowser(),this.isEdge=this.browser===N.EDGE,this.isInternetExplorer=this.browser===N.IE,this.isInternetExplorerOrEdge=this.isEdge||this.isInternetExplorer,this.isFirefox=this.browser===N.FIREFOX,this.isFirefoxMobile=this.browser===N.FIREFOX_MOBILE,this.isFirefoxOrFirefoxMobile=this.isFirefox||this.isFirefoxMobile,this.isSamsungInternet=this.browser===N.SAMSUNG_INTERNET,this.isUCBrowser=this.browser===N.UC_BROWSER,this.isChrome=this.browser===N.CHROME,this.isSafari=this.browser===N.SAFARI,this.isOpera=this.browser===N.OPERA,this.isBlackberry=this.browser===N.BLACKBERRY,this.isOperaMobile=this.browser===N.OPERA_MOBILE,this.isIEMobile=this.browser===N.IE_MOBILE,this.isOperaMini=this.browser===N.OPERA_MINI,this.isNative=null!=C.cordova,this.isAndroidBrowser=this.browser===N.ANDROID_STOCK&&!this.isNative,this.isMobile=this.isNative||/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino/i.test(navigator.userAgent),this.nativePlatform=this.detectNativePlatform(),this.isIOSDevice=this.isIOSAgent()||this.nativePlatform===D.IOS,this.isIPhoneDevice=/iphone|ipod/i.test(this.agent),this.isIPadDevice=/ipad/i.test(this.agent),this.isSafariOnDesktop=this.browser===N.SAFARI&&!this.isMobile,this.isSafariOnMobile=this.isMobile&&!this.isNative&&this.browser===N.SAFARI,this.isNativeIOS=this.nativePlatform===D.IOS,this.isNativeAndroid=this.nativePlatform===D.ANDROID,this.isAndroidDevice=this.isNativeAndroid||this.agent.includes("android"),this.isAppleDevice=this.isNativeIOS||this.browser===N.SAFARI,this.isDesktopDevice=!this.isMobile,this.isWebkitBrowser=this.agent.includes("applewebkit"),this.iOSVersion=this.isIOSDevice?this.detectIOSVersion():-1,this.IEVersion=this.isInternetExplorer?this.detectIEVersion():-1,this.chromeVersion=this.isChrome?this.detectChromeVersion():-1,this.firefoxVersion=this.isFirefox?this.detectFirefoxVersion():-1,this.safariVersion=this.isSafari?this.detectSafariVersion():-1,this.edgeVersion=this.isEdge?this.detectEdgeVersion():-1,this.operaVersion=this.isOpera?this.detectOperaVersion():-1,this.operaMiniVersion=this.isOperaMini?this.detectOperaMiniVersion():-1,this.operaMobileVersion=this.isOperaMobile?this.detectOperaMobileVersion():-1,this.androidVersion=this.isAndroidDevice?this.detectAndroidVersion():-1,this.samsungInternetVersion=this.isSamsungInternet?this.detectSamsungInternetVersion():-1,this.firefoxMobileVersion=this.isFirefoxMobile?this.detectFirefoxMobileVersion():-1,this.UCBrowserVersion=this.isFirefoxMobile?this.detectUCBrowserVersion():-1,this.IEMobileVersion=this.isIEMobile?this.detectIEMobileVersion():-1,this.browserVersion=(()=>{return this.isIOSDevice?this.iOSVersion:this.isInternetExplorer?this.IEVersion:this.isChrome?this.chromeVersion:this.isFirefox?this.firefoxVersion:this.isSafari?this.safariVersion:this.isEdge?this.edgeVersion:this.isOpera?this.operaVersion:this.isOperaMini?this.operaMiniVersion:this.isOperaMobile?this.operaMobileVersion:this.isAndroidDevice?this.androidVersion:this.isSamsungInternet?this.samsungInternetVersion:this.isFirefoxMobile?this.firefoxMobileVersion:this.isUCBrowser?this.UCBrowserVersion:this.isIEMobile?this.IEMobileVersion:-1})(),this.vendorPrefix=(()=>{return this.isWebkitBrowser?"webkit":this.isFirefoxOrFirefoxMobile?"moz":""})(),this.vendorPrefixDashed=(()=>{return this.isWebkitBrowser?"-webkit-":this.isFirefoxOrFirefoxMobile?"-moz-":""})()}detectIOSVersion(){const Ae=this.agent.match(/cpu.*os {0,1}_{0,1}([0-9_]{1})|(cpu like).*applewebkit.*mobile/i);return null==Ae?-1:parseInt(Ae[1])}detectIEMobileVersion(){const Ae=this.agent.match(/iemobile\/{0,1} {0,1}(\d{1})/i);return null==Ae?-1:parseInt(Ae[1])}detectAndroidVersion(){const Ae=this.agent.match(/android (\d{1,3})/i);return null==Ae?-1:parseInt(Ae[1])}detectSamsungInternetVersion(){const Ae=this.agent.match(/(?:samsung|smart-tv).*(?:samsungbrowser|web browser)\/(\d{1,2})/i);return null==Ae?/armv7l/.test(this.agent)||/version\/\d{1,2}/.test(this.agent)?1:-1:parseInt(Ae[1])}detectUCBrowserVersion(){const Ae=/ucbrowser|uc browser/i.test(this.agent)?this.agent.match(/(?:ucbrowser|uc browser)\/{0,1}(\d{1,2})/i):this.agent.match(/(?!ucweb)\/{0,1}(\d{1,2})/i);return null==Ae?-1:parseInt(Ae[1])}detectFirefoxMobileVersion(){const Ae=this.agent.match(/firefox\/(\d{1,2})/i);return null==Ae?-1:parseInt(Ae[1])}detectIEVersion(){return document.all?document.all&&!document.compatMode?5:document.all&&!C.XMLHttpRequest?6:document.all&&!document.querySelector?7:document.all&&!document.addEventListener?8:document.all&&!C.atob?9:document.all?10:-1:11}detectChromeVersion(){let Ae=this.agent.match(/chrome\/(\d{1,2})/i);return null==Ae?(null==Ae&&(Ae=this.agent.match(/(chrome)\/\s{1}safari/i)),null==Ae?-1:0):parseInt(Ae[1])}detectSafariVersion(){const Ae=this.agent.match(/version\/(\d{1,2})/i);if(null!=Ae)return parseInt(Ae[1]);const Oe=this.agent.match(/applewebkit\/(\d{1,4})/i);if(null!=Oe){const Re=parseFloat(Oe[1]);return Re>=601?9:Re>=538?8:Re>=537?7:Re>=536?6:Re>=533?5:Re>=526?4:Re>=522?3:Re>=412?2:Re>=85?1:0}return-1}detectFirefoxVersion(){const Ae=this.agent.match(/firefox\/(\d{1,})/i);return Ae?parseInt(Ae[1]):-1}detectEdgeVersion(){const Ae=this.agent.match(/edge\/(\d{1,3})/i);return Ae?parseInt(Ae[1]):-1}detectOperaVersion(){const Ae=this.agent.match(/[opera|opr]+\/(\d{1,3})/i);return Ae?parseInt(Ae[1]):-1}detectOperaMiniVersion(){let Ae=this.agent.match(/opera mini\/(\d{1,3})/i);return null==Ae?(Ae=this.agent.match(/opera mini\/([symbianos|nokia|mozilla|(windows]+)/i),Ae?0:-1):parseInt(Ae[1])}detectOperaMobileVersion(){let Ae=this.agent.match(/version\/(\d{1,3})/i);return null==Ae?(Ae=this.agent.match(/opera (\d{1,3})/i),Ae?parseInt(Ae[1]):-1):parseInt(Ae[1])}isIOSAgent(){return /iphone|ipad|ipod/i.test(this.agent)}isChromeAgent(){return-1!==this.agent.indexOf("chrome")&&-1===this.agent.indexOf("edge")&&-1===this.agent.indexOf("chromeframe")&&!this.isIOSAgent()}detectNativePlatform(){if(!this.isNative)return null;const Ae=C.device?C.device.platform:null;if(null!=Ae){const Oe=Ae.toUpperCase();if(Oe===D[D.ANDROID])return D.ANDROID;if(Oe===D[D.IOS])return D.IOS}return this.browser===N.SAFARI?D.IOS:D.ANDROID}detectBrowser(){const Ae=this.agent;return(Ae.includes("ucbrowser")||Ae.includes("ucweb")||Ae.includes("uc browser"))&&!this.isChromeAgent()&&!this.isIOSAgent()?N.UC_BROWSER:Ae.includes("opera mini/")?N.OPERA_MINI:-1===Ae.indexOf("opera mobi/")||this.isIOSAgent()||this.isChromeAgent()?(Ae.includes("opera")||Ae.includes("opr/")||Ae.includes("oupeng/"))&&!this.isIOSAgent()&&!this.isChromeAgent()?N.OPERA:Ae.includes("blackberry")&&!this.isIOSAgent()?N.BLACKBERRY:Ae.includes("iemobile")?N.IE_MOBILE:this.isChromeAgent()?N.CHROME:Ae.includes("samsung")||Ae.includes("smart-tv")?N.SAMSUNG_INTERNET:Ae.includes("firefox")&&/mobile|tablet|tv/.test(Ae)&&!this.isIOSAgent()?N.FIREFOX_MOBILE:Ae.includes("firefox")?N.FIREFOX:Ae.includes("android")?N.ANDROID_STOCK:Ae.includes("safari")&&!Ae.includes("edge")||Ae.includes("iphone")||Ae.includes("ipod")||Ae.includes("ipad")?N.SAFARI:Ae.includes("msie")||!0==!!document.documentMode||!C.ActiveXObject&&"ActiveXObject"in C||Ae.includes("rv:11.0")?N.IE:Ae.includes("edge")?N.EDGE:N.UNKNOWN:N.OPERA_MOBILE}},F=new class{constructor(){this.boundEventHandlers=new Map}fire(Ae,Oe=window,Re=null){const we=Object.assign({},{detail:Re}),ve=new CustomEvent(Ae,we);return Oe.dispatchEvent(ve),ve}waitFor(Ae,Oe){return new Promise((Re)=>{const we=function(ve){Oe.removeEventListener(Ae,we),Re(ve)};Oe.addEventListener(Ae,we)})}waitForAny(Ae,Oe){return new Promise((Re)=>{let we=!1;Ae.forEach(async(ve)=>{const be=await this.waitFor(ve,Oe);we||(we=!0,Re(be))})})}listen(Ae,Oe,Re,we,ve=!0,be=!1,Se){const Te=we.bind(Se||Ae),Ne=be?(Me)=>{const _e=Me.currentTarget;requestAnimationFrame(()=>Te(Me,_e))}:Te;Re.addEventListener(Oe,Ne,{passive:ve,capture:!1});const De=this.boundEventHandlers.get(Ae)||[];De.push({listener:Ne,unbound:we,eventName:Oe,on:Re}),this.boundEventHandlers.set(Ae,De)}unlisten(Ae,Oe,Re,we){const ve=this.boundEventHandlers.get(Ae);if(null!=ve){const be=ve.find((Se)=>Se.eventName===Oe&&Se.on===Re&&Se.unbound===we);if(null==be)throw new ReferenceError(`Could not find an associated handler to unbind for event: '${Oe}' with handler: '${we.toString()}' for binder: '${Ae.nodeName.toLowerCase()}'`);Re.removeEventListener(Oe,be.listener),this.boundEventHandlers.delete(Ae)}}clearListeners(Ae){this.boundEventHandlers.forEach((Oe,Re)=>{null!=Ae&&Re!==Ae||Oe.forEach((we)=>this.unlisten(Re,we.eventName,we.on,we.unbound))})}},B=new l,y=new class{async wait(Ae=0){return new Promise((Oe)=>setTimeout(Oe,Ae))}},V=new class{animate(Ae,Oe,Re){return new Promise((we,ve)=>{try{requestAnimationFrame(()=>{const be=Ae.animate(Oe,Re);return Re.iterations===Infinity?we(be):void(be.onfinish=be.oncancel=()=>{we(be)})})}catch(be){ve(be)}})}};let U=class extends HTMLElement{constructor(){super(),this.role="presentation",this.tabindex="-1",this.cachedElementLookups=new Map,this.injectTemplate()}get domRoot(){return null==this.shadowRoot?this:this.shadowRoot}static styles(){return null}static markup(){return null}injectTemplate(){const Oe=this.constructor;if(null!=Oe.template){const Re=this.attachShadow({mode:"open"}),we=document.importNode(Oe.template.content,!0);Re.appendChild(we)}}element(Oe){const Re=this.getCachedElement(Oe);if(null!=Re)return Re;const we=null==this.shadowRoot?this.querySelector(`#${Oe}`):this.shadowRoot.querySelector(`#${Oe}`);return null==we?this.setCachedElement(Oe,null==this.shadowRoot?document.querySelector(Oe):this.shadowRoot.querySelector(Oe)):this.setCachedElement(Oe,we)}connectedCallback(){this.setAttribute("role",this.role),this.setAttribute("tabindex",this.tabindex)}disconnectedCallback(){}getCachedElement(Oe){return this.cachedElementLookups.get(Oe)}setCachedElement(Oe,Re){return this.cachedElementLookups.set(Oe,Re),Re}};U.template=null,U=o([a("component-element")],U);let G=class extends U{static get observedAttributes(){return["icon"]}static styles(){return`
			:host-context([center]),
			:host([center]) {
				margin: 0 auto;
			}
			
			#fill_target,
			:host {
				fill: var(--color-icon-dark);
			}
			
			:host([light]) #fill_target,
			:host([light]) {
				fill: var(--color-icon-light);
			}
			
			:host([dark]) #fill_target,
			:host([dark]) {
				fill: var(--color-icon-dark);
			}
			
			:host([primary]) #fill_target,
			:host([primary]) {
				fill: var(--color-primary-100);
			}
			
			:host([accent]) #fill_target,
			:host([accent]) {
				fill: var(--color-accent-100);
			}
			
			:host([warning]) #fill_target,
			:host([warning]) {
				fill: var(--color-red-100);
			}
			
			:host {
				user-select: none;
				backface-visibility: hidden;
				transform: translate3d(0,0,0);
				position: relative;
				vertical-align: middle;
				width: var(--width-icon-small);
				height: var(--height-icon-small);
				pointer-events: none;
				contain: size layout style;
				overflow: hidden;
				flex-shrink: 0;
				display: inline-flex;
				justify-content: center;
				align-items: center;
			}
			
			:host([small]) {
				width: var(--width-icon-small);
				height: var(--height-icon-small);
			}
			
			:host([medium]) {
				width: var(--width-icon-medium);
				height: var(--height-icon-medium);
			}
			
			:host([large]) {
				width: var(--width-icon-large);
				height: var(--height-icon-large);
			}
			
			:host([larger]) {
				width: var(--width-icon-larger);
				height: var(--height-icon-larger);
			}
			
			:host([huge]) {
				width: var(--width-icon-huge);
				height: var(--height-icon-huge);
			}
			
			:host([extreme]) {
				width: var(--width-icon-extreme);
				height: var(--height-icon-extreme);
			}
		`}attributeChangedCallback(Oe,Re,we){switch(Oe){case"icon":if(null!=we){const ve=B.buildIconFromName(we);if(null==ve)throw ReferenceError(`Failed to build an SVG for icon: ${we}`);this.svg=ve,this.setSvg(ve)}else this.svg=null,this.clearSvg();}}setSvg(Oe){null==this.shadowRoot?this.appendChild(Oe):this.shadowRoot.appendChild(Oe)}clearSvg(){const Oe=null==this.shadowRoot?this:this.shadowRoot,Re=Oe.querySelector("svg");null==Re||Oe.removeChild(Re)}};G=o([a("icon-element")],G);let k=class extends U{constructor(){super(...arguments),this.role="navigation"}static styles(){return`
			
			:host([primary]) {
				background: var(--color-primary-100);
			}
			
			:host([accent]) {
				background: var(--color-accent-100);
			}
			
			:host([dark]) {
				background: var(--color-black-70);
			}
			
			:host([light]) {
				background: var(--color-white-87);
			}

			:host {
				box-sizing: border-box;
				position: fixed;
				top: 0;
				left: 0;
				right: 0;
				width: 100%;
				height: var(--app-bar-portrait-height-desktop);
				box-shadow: var(--shadow-level1);
				z-index: 998;
			}
	
			#titleSlot::slotted(*),
			#leftIconSlot::slotted(*) {
				position: absolute;
				top: 0 !important;
				bottom: 0 !important;
				margin-top: auto !important;
				margin-bottom: auto !important;
			}
			
			#titleSlot::slotted(*) {
				user-select: none !important;
				left: calc(var(--distance-minimum) + var(--width-icon-medium) + var(--distance-minimum)) !important;
				height: var(--font-size-title) !important;
				line-height: 17px !important;
				vertical-align: middle !important;
				padding: 0 !important;
			}
	
			#leftIconSlot::slotted(*) {
				left: var(--distance-minimum) !important;
				border-radius: 50% !important;
			}
		`}static markup(){return`
			<slot id="leftIconSlot" name="leftIcon"></slot>
			<slot id="titleSlot" name="title"></slot>
		`}};k=o([a("app-bar-element")],k);let W=class extends U{constructor(){super(...arguments),this.role="navigation"}static styles(){return`
			#title {
				color: var(--color-primary-text-light);
			}
		`}static markup(){return`
			<app-bar-element primary>
				<icon-element icon="fovea-logo" slot="leftIcon" light medium></icon-element>
				<h6 id="title" slot="title">Fovea</h6>
			</app-bar-element>
		`}};W=o([a("fovea-app-bar-element")],W);let Y=class extends U{constructor(){super(...arguments),this.role="complementary"}static styles(){return`

		:host([center]) {
			align-content: center;
			justify-content: center;
			text-align: center;
		}
		
		:host([center]) ::slotted(*) {
			text-align: center;
		}
		
		:host([center]) ::slotted(p),
		:host([center]) ::slotted(strong),
		:host([center]) ::slotted(span),
		::slotted(*) {
			text-align: justify;
		}
		
		::slotted(button-element) {
			align-self: flex-end;
			justify-self: flex-end;
		}
		
		:host {
			max-width: 369px;
			min-width: 200px;
			margin: 0;
			padding: var(--distance-regular);
			width: auto;
			position: relative;
			display: flex;
			flex-direction: column;
			background: var(--color-white-100);
			box-shadow: var(--shadow-level4);
			contain: content;
			border-radius: var(--box-radius);
		}
		
		:host([shadow="1"]) {
			box-shadow: var(--shadow-level1);
		}
		
		:host([shadow="2"]) {
			box-shadow: var(--shadow-level2);
		}
		
		:host([shadow="3"]) {
			box-shadow: var(--shadow-level3);
		}
		
		:host([shadow="4"]) {
			box-shadow: var(--shadow-level4);
		}
		
		:host([shadow="5"]) {
			box-shadow: var(--shadow-level5);
		}
		
		:host([shadow="6"]) {
			box-shadow: var(--shadow-level6);
		}
		
		:host([shadow="7"]) {
			box-shadow: var(--shadow-level7);
		}
		
	`}static markup(){return`
			<slot></slot>
		`}};Y=o([a("card-element")],Y);let K=class extends U{constructor(){super(...arguments),this.role="complementary"}static markup(){return`
			<card-element center>
						<h4>Tiny</h4>
						<p>The days of huge monolithic Javascript bundles are over. Our users deserve better. Fovea compiles your view components into DOM-instructions ahead-of-time and then gets out of the way. Completely.</p>
						<div class="flex"></div>
						<icon-element icon="fovea-tiny" larger primary></icon-element>
				</card-element>
		
				<card-element center>
						<h4>Super fast</h4>
						<p>No dirty checking. No DOM traversal or parsing. Instead, Fovea maps your bindings directly to nodes and does all the heavy lifting on compile time. When something changes, Fovea simply looks up the bound node and updates the value immediately.</p>
						<div class="flex"></div>
						<icon-element icon="fovea-fast" larger primary></icon-element>
				</card-element>
		
				<card-element center>
						<h4>Intuitive</h4>
						<p>Fovea is built on modern standards such as Custom Elements and declarative data binding through string interpolation. It believes that the DOM is fast as it is with no need to ship an entire virtual DOM implementation on runtime.</p>
						<div class="flex"></div>
						<icon-element icon="fovea-intuitive" larger primary></icon-element>
				</card-element>
		`}static styles(){return`

			:host {
				width: 100%;
				justify-content: center;
				align-content: center;
				position: relative;
				display: inline-flex;
				flex-direction: column;
				margin: 0;
			}
			
			card-element > p,
			card-element > h4 {
				user-select: text;
			}
			
			card-element {
				margin: var(--distance-minimum) auto;
			}
			
			.flex {
				flex-grow: 1;
			}
			
			@media screen and (min-width: 700px) {
				:host {
					flex-direction: row;
				}
				
				card-element {
					margin: var(--distance-minimum);
				}
			
				card-element:first-of-type {
					margin-left: var(--distance-minimum);
					margin-right: calc(var(--distance-minimum) / 2);
				}
			
				card-element:last-of-type {
					margin-right: var(--distance-minimum);
					margin-left: calc(var(--distance-minimum) / 2);
				}
			
				card-element > icon-element {
					margin-top: var(--distance-regular);
				}
			}
		`}};K=o([a("highlights-element")],K);let X=Z=class extends U{constructor(){super(),this.role="list",L.isIOSDevice&&!Z.BOUND_BODY_LISTENER&&(Z.BOUND_BODY_LISTENER=!0,F.listen(this,"touchmove",document.body,Z.onBodyTouchMove,!1))}static markup(){return`<slot></slot>`}static styles(){return`

			:host {
				transform: translate3d(0,0,0);
				backface-visibility: hidden;
				box-sizing: border-box;
				contain: content;
				position: relative;
				display: block;
				width: 100%;
			}

			:host,
			:host([direction="y"]),
			:host([direction="Y"]) {
				overflow-y: scroll;
				overflow-x: hidden;
			}
			
			:host([direction="x"]),
			:host([direction="X"]) {
				overflow-y: hidden;
				overflow-x: scroll;
			}
			
			:host([direction="x"]),
			:host([direction="X"]) {
				overflow-y: hidden;
				overflow-x: scroll;
			}
			
			:host([direction="both"]),
			:host([direction="both"]) {
				overflow-y: scroll;
				overflow-x: scroll;
				overflow: scroll;
			}
		`}static onBodyTouchMove(Oe){if(Oe.cancelable&&!Oe._isScroller)return Oe.preventDefault()}async connectedCallback(){super.connectedCallback(),this.listenForScrollTarget(this),await this.connectScroller()}disconnectedCallback(){super.disconnectedCallback(),this.unlistenForScrollTarget(this)}async connectScroller(){L.isIOSDevice&&(await y.wait(1e3),this.style.webkitOverflowScrolling="touch")}listenForScrollTarget(Oe){L.isIOSDevice&&(F.listen(this,"touchstart",Oe,this.onScrollTargetTouchstart),F.listen(this,"touchmove",Oe,this.onScrollTargetTouchmove))}unlistenForScrollTarget(Oe){L.isIOSDevice&&(F.unlisten(this,"touchstart",Oe,this.onScrollTargetTouchstart),F.unlisten(this,"touchmove",Oe,this.onScrollTargetTouchmove))}canScroll(Oe){if(!(Oe instanceof HTMLElement))return!1;if(Oe.scrollHeight===Oe.offsetHeight)throw new TypeError(`scrollTarget is either not visible or hasn't got a fixed height and display style property. Couldn't decide scrollability`);return Oe.scrollHeight>Oe.offsetHeight}fixScrollBounds(Oe){if(Oe instanceof HTMLElement){const{scrollTop:Re}=Oe;0===Re?Oe.scrollTop=1:Re+Oe.offsetHeight===Oe.scrollHeight&&(Oe.scrollTop=Re-1)}}onScrollTargetTouchstart(Oe){this.fixScrollBounds(Oe.currentTarget)}onScrollTargetTouchmove(Oe){this.canScroll(Oe.currentTarget)&&(Oe._isScroller=!0)}};X.BOUND_BODY_LISTENER=!1,X=Z=o([a("scroll-element")],X);var Z;let q=class extends U{constructor(){super(...arguments),this.role="figure"}static styles(){return`
			:host-context([center]),
			:host([center]) {
				margin-left: auto;
				margin-right: auto;
				text-align: center;
			}

			:host {
				background: var(--color-dark-hex);
				border-radius: var(--box-radius);
				margin: 0;
				padding: var(--distance-minimum);
				width: auto;
				position: relative;
				display: flex;
				contain: content;
				flex-direction: column;
				text-align: left;
			}
			
			scroll-element {
				max-height: inherit;
			}
			
			:host,
			scroll-element,
			::slotted(*) {
				user-select: text !important;
				cursor: text !important;
			}
			
			::slotted(*) {
				font-family: var(--font-family-monospace) !important;
				color: var(--color-white-87);
				font-size: var(--font-size-mono);
				line-height: var(--font-size-mono);
				display: inline;
			}
			
			::slotted(.keyword) {
				color: var(--color-syntax-keyword);
			}
			
			::slotted(.identifier) {
				color: var(--color-syntax-identifier);
			}
			
			::slotted(.bracket) {
				color: var(--color-syntax-bracket);
			}
			
			::slotted(.decorator) {
				color: var(--color-syntax-decorator);
			}
			
			::slotted(.property) {
				color: var(--color-syntax-property);
			}
			
			::slotted(.token) {
				color: var(--color-syntax-token);
			}
			
			::slotted(.type) {
				color: var(--color-syntax-type);
			}
			
			::slotted(.method) {
				color: var(--color-syntax-method);
			}
			
			::slotted(.function) {
				color: var(--color-syntax-function);
			}
			
			::slotted(.tagname) {
				color: var(--color-syntax-tagname);
			}
			
			::slotted(.string) {
				color: var(--color-syntax-string);
			}
			
			::slotted(.attribute_name) {
				color: var(--color-syntax-attribute-name);
			}
			
			::slotted(.attribute_value) {
				color: var(--color-syntax-attribute-value);
			}
			
			::slotted(.css_selector_name) {
				color: var(--color-syntax-css-selector-name);
			}
			
			::slotted(.css_property_name) {
				color: var(--color-syntax-css-property-name);
			}
			
			::slotted(.variable) {
				color: var(--color-syntax-variable);
			}
			
			::slotted(.number) {
				color: var(--color-syntax-number);
			}
			
			::slotted(.comment) {
				color: var(--color-syntax-comment);
			}
		`}static markup(){return`
			<scroll-element direction="both">
				<slot></slot>
			</scroll-element>
		`}};q=o([a("code-element")],q);let j=class extends U{static styles(){return`
			:host {
				position: absolute;
				top: 0;
				left: 0;
				width: 100%;
				height: 100%;
				contain: strict;
				backface-visibility: hidden;
				transform: translate3d(0,0,0);
				overflow: hidden;
			}
			
			:host([dark]) icon-element,
			icon-element {
				fill: var(--color-black-02);
			}
			
			:host([primary]) icon-element {
				fill: var(--color-primary-06);
			}
			
			:host([accent]) icon-element {
				fill: var(--color-accent-06);
			}
			
			:host([light]) icon-element {
				fill: var(--color-white-12);
			}
			
			:host([warning]) icon-element {
				fill: var(--color-red-12);
			}
			
			
			icon-element {
				width: 200vw;
				height: 200vw;
				position: absolute;
				z-index: 0;
				contain: strict;
				backface-visibility: hidden;
				overflow: hidden;
			}
			
			#triangle1 {
				top: -20vw;
				left: -80vw;
				transform: rotate(-24deg) translateZ(0);
			}
			
			#triangle2 {
				top: -50vw;
				left: -40vw;
				transform: rotate(23deg) translateZ(0);
			}
		`}static markup(){return`
			<icon-element id="triangle1" icon="material-triangle"></icon-element>
			<icon-element id="triangle2" icon="material-triangle"></icon-element>
		`}};j=o([a("material-triangles-element")],j);let z=class extends U{constructor(){super(...arguments),this.role="banner"}static styles(){return`
			:host {
				width: 100%;
				display: flex;
				align-content: center;
				padding-top: var(--app-bar-landscape-height-mobile);
				flex-direction: column;
				position: relative;
				background: var(--color-accent-100);
				contain: content;
				backface-visibility: hidden;
				transform: translate3d(0,0,0);
				overflow: hidden;
				padding-bottom: 60px;
			}
			
			::slotted(*) {
				text-align: center;
				z-index: 1;
				margin: 0 auto;
			}
		`}static markup(){return`
			<slot></slot>
			<material-triangles-element></material-triangles-element>
		`}};z=o([a("hero-element")],z);let J=class extends U{constructor(){super(...arguments),this.pointerDown=!1,this.complexAnimating=!1,this.oneShotAnimating=!1,this.initialWaitTime=0.2,this.oneShotAnimationDuration=0.5,this.lastCoordinates=null}static get observedAttributes(){return["pointer-down"]}listenForTarget(Oe){F.listen(this,"click",Oe,this.onPointerTap),F.listen(this,"pointerdown",Oe,this.onPointerDown),F.listen(this,"pointerup",Oe,this.onPointerUp),F.listen(this,"pointercancel",Oe,this.onPointerCancel),F.listen(this,"pointerleave",Oe,this.onPointerLeave)}unlistenFromTarget(Oe){F.unlisten(this,"click",Oe,this.onPointerTap),F.unlisten(this,"pointerdown",Oe,this.onPointerDown),F.unlisten(this,"pointerup",Oe,this.onPointerUp),F.unlisten(this,"pointercancel",Oe,this.onPointerCancel),F.unlisten(this,"pointerleave",Oe,this.onPointerLeave)}async onPointerDown({offsetX:Oe,offsetY:Re,width:we,height:ve}){this.lastCoordinates=-1===we&&-1===ve?null:{offsetX:Oe,offsetY:Re},this.pointerDown||(this.pointerDown=!0,this.setAttribute("pointer-down",""))}async onPointerUp(){this.pointerDown&&(this.pointerDown=!1,this.hasAttribute("pointer-down")&&this.removeAttribute("pointer-down"))}async onPointerCancel(){await this.onPointerUp()}async onPointerLeave(){await this.onPointerUp()}async onPointerTap(){this.complexAnimating||(this.oneShotAnimating?await this.attributeChangedCallback("one-shot-animating","true","true"):(this.oneShotAnimating=!0,this.setAttribute("one-shot-animating","")))}connectedCallback(){super.connectedCallback();const Oe=this.getRootNode().host;null==this.target&&null!=Oe&&(this.target=Oe,this.listenForTarget(this.target))}async attributeChangedCallback(Oe){return"pointer-down"===Oe?await this.onPointerDownChanged(this.pointerDown):void 0}async onPointerDownChanged(Oe){Oe&&(await y.wait(1e3*this.initialWaitTime),this.pointerDown&&!this.oneShotAnimating&&(this.complexAnimating=!0,this.setAttribute("complex-animating","")))}};J=o([a("feedback-composite")],J);let $=Q=class extends J{constructor(){super(...arguments),this.rippleEasing="linear",this.highlightAmount=Q.HIGHLIGHT_AMOUNT,this.rippleHighlightAmount=Q.RIPPLE_HIGHLIGHT_AMOUNT,this.highlightDuration=0.7,this.rippleDuration=5}static get observedAttributes(){return["light","one-shot-animating","complex-animating","pointer-down"]}static markup(){return`<aside id="highlight"></aside>`}static styles(){return`

			#highlight {
				visibility: hidden;
				background-color: currentcolor;
				opacity: 0;
				width: 100%;
				height: 100%;
				top: 0;
				left: 0;
				right: 0;
				bottom: 0;
			}

			:host([one-shot-animating]) #highlight,
			:host([complex-animating]) #highlight {
				visibility: visible;
			}

			:host > div, #highlight {
				user-select: none;
				position: absolute;
				pointer-events: none;
				contain: strict;
			}

			:host > div {
				position: absolute;
				display: block;
				border-radius: 50%;
				background-color: currentcolor;
				transform: scale(0) translateZ(0);
				width: 0;
  			height: 0;
				opacity: 0;
			}
		`}async animateOneShot(Oe){null==Oe&&(Oe=await this.createAndAddRipple());null==Oe||(await Promise.all([V.animate(Oe,{opacity:[this.rippleHighlightAmount,0],transform:["scale(0) translateZ(0)","scale(1) translateZ(0)"]},{duration:1e3*this.oneShotAnimationDuration,easing:this.rippleEasing}),null==this.element("highlight")?Promise.resolve():V.animate(this.element("highlight"),{opacity:[0,this.highlightAmount,0]},{duration:1e3*this.oneShotAnimationDuration,easing:this.rippleEasing})]),this.clearRipple(Oe))}async attributeChangedCallback(Oe,Re,we){await super.attributeChangedCallback(Oe,Re,we);"light"===Oe?we&&(this.rippleHighlightAmount=Q.RIPPLE_LIGHT_HIGHLIGHT_AMOUNT,this.highlightAmount=Q.HIGHLIGHT_LIGHT_AMOUNT):"one-shot-animating"===Oe?this.oneShotAnimating&&(await Promise.all([this.animateOneShot(),this.whenAllRipplesHasFinishedAnimating()]),this.oneShotAnimating=!1,this.hasAttribute("one-shot-animating")&&this.removeAttribute("one-shot-animating")):"complex-animating"===Oe?this.complexAnimating&&(await this.animateIn()):"pointer-down"===Oe?!this.complexAnimating||this.pointerDown||this.oneShotAnimating||(await this.animateOut(),this.complexAnimating=!1,this.hasAttribute("complex-animating")&&this.removeAttribute("complex-animating")):void 0}connectedCallback(){super.connectedCallback(),null!=this.target&&this.prepareTarget(this.target)}getTargetDimensions(){return null==this.target?void 0:this.target.getBoundingClientRect()}computeRippleDimensions(){const Oe=this.getTargetDimensions();if(null==Oe)return;const{width:Re,height:we}=Oe;let ve=_Mathmax(Re,we)+_Mathmax(Re,we)/2;if(null!=this.lastCoordinates&&!this.hasAttribute("center")){const be=_Mathabs(Re/2-this.lastCoordinates.offsetX),Se=_Mathabs(we/2-this.lastCoordinates.offsetY);ve+=be+Se+Q.RIPPLE_ADDITIONAL_SIZE}return{width:Re,height:we,size:ve}}getRippleStyles(){const Oe=this.computeRippleDimensions();if(null!=Oe){const{width:Re,height:we,size:ve}=Oe,be=this.hasAttribute("center")||null==this.lastCoordinates?we/2-ve/2:this.lastCoordinates.offsetY-ve/2,Se=this.hasAttribute("center")||null==this.lastCoordinates?Re/2-ve/2:this.lastCoordinates.offsetX-ve/2;return[{prop:"top",value:`${be}px`},{prop:"left",value:`${Se}px`},{prop:"width",value:`${ve}px`},{prop:"height",value:`${ve}px`}]}}createRipple(){const Oe=this.getRippleStyles();if(null==Oe)throw new ReferenceError(`RippleComposite could not get styles for undefined target!`);const Re=document.createElement("div");return Oe.forEach((we)=>Re.style[we.prop]=we.value),Re}async whenAllRipplesHasFinishedAnimating(){if(null!=this.lastRipple)return await y.wait(100),await this.whenAllRipplesHasFinishedAnimating()}clearRipple(Oe){null!=this.shadowRoot&&this.shadowRoot.contains(Oe)&&(this.shadowRoot.removeChild(Oe),this.lastRipple===Oe&&(this.lastRipple=null))}async createAndAddRipple(){const Oe=this.createRipple();return null==Oe?null:(null==this.shadowRoot?this.appendChild(Oe):this.shadowRoot.appendChild(Oe),this.lastRipple=Oe,await y.wait(Q.ANIMATION_FRAME_DELAY),Oe)}async animateHighlightIn(){await V.animate(this.element("highlight"),{opacity:[0,this.highlightAmount]},{duration:1e3*this.highlightDuration,easing:this.rippleEasing,fill:"forwards"})}async animateHighlightOut(){let Oe=window.getComputedStyle(this.element("highlight")).opacity;null==Oe&&(Oe=this.highlightAmount),await V.animate(this.element("highlight"),{opacity:[Oe,0]},{duration:1e3*this.oneShotAnimationDuration,easing:this.rippleEasing,fill:"forwards"})}async animateIn(){if(await this.animateHighlightIn(),!!this.pointerDown){const Oe=await this.createAndAddRipple();null==Oe||(await V.animate(Oe,{opacity:[this.rippleHighlightAmount,0],transform:["scale(0) translateZ(0)","scale(1) translateZ(0)"]},{duration:1e3*this.rippleDuration,easing:this.rippleEasing}))}}async animateOut(){if(null==this.lastRipple)return await this.animateHighlightOut();const Oe=window.getComputedStyle(this.lastRipple),Re=null==Oe.opacity?this.rippleHighlightAmount:Oe.opacity,we=null==Oe.transform?"scale(0) translateZ(0)":Oe.transform;await Promise.all([V.animate(this.lastRipple,{opacity:[Re,0],transform:[we,"scale(1) translateZ(0)"]},{duration:1e3*this.oneShotAnimationDuration,easing:this.rippleEasing}),this.animateHighlightOut()]),this.clearRipple(this.lastRipple)}prepareTarget(Oe){Oe.style.overflow=Oe.style.overflow||"hidden"}};$.RIPPLE_ADDITIONAL_SIZE=50,$.ANIMATION_FRAME_DELAY=20,$.RIPPLE_HIGHLIGHT_AMOUNT=0.3,$.HIGHLIGHT_AMOUNT=0.2,$.RIPPLE_LIGHT_HIGHLIGHT_AMOUNT=0.18,$.HIGHLIGHT_LIGHT_AMOUNT=0.08,$=Q=o([a("ripple-composite")],$);var Q,ee;(function(Ae){Ae[Ae.SPACEBAR=32]="SPACEBAR",Ae[Ae.HTML_SPACE=160]="HTML_SPACE",Ae[Ae.ENTER=13]="ENTER",Ae[Ae.BACKSPACE=8]="BACKSPACE",Ae[Ae.TAB=9]="TAB",Ae[Ae.LEFT_COMMAND_OR_WINDOWS_KEY=91]="LEFT_COMMAND_OR_WINDOWS_KEY",Ae[Ae.RIGHT_COMMAND_OR_WINDOWS_MENU=93]="RIGHT_COMMAND_OR_WINDOWS_MENU",Ae[Ae.ALT=18]="ALT",Ae[Ae.CONTROL=17]="CONTROL",Ae[Ae.SHIFT=16]="SHIFT",Ae[Ae.LEFT_ARROW=37]="LEFT_ARROW",Ae[Ae.UP_ARROW=38]="UP_ARROW",Ae[Ae.RIGHT_ARROW=39]="RIGHT_ARROW",Ae[Ae.DOWN_ARROW=40]="DOWN_ARROW",Ae[Ae.ESCAPE=27]="ESCAPE",Ae[Ae.ZERO=48]="ZERO",Ae[Ae.ONE=49]="ONE",Ae[Ae.TWO=50]="TWO",Ae[Ae.THREE=51]="THREE",Ae[Ae.FOUR=52]="FOUR",Ae[Ae.FIVE=53]="FIVE",Ae[Ae.SIX=54]="SIX",Ae[Ae.SEVEN=55]="SEVEN",Ae[Ae.EIGHT=56]="EIGHT",Ae[Ae.NINE=57]="NINE"})(ee||(ee={}));let ne=ie=class extends U{constructor(){super(...arguments),this.pointerInitiated=!1}styles(){return`
			:host {
				display: none;
			}
		`}listenForTarget(Oe){F.listen(this,"pointerdown",Oe,this.onTargetPointerDown),F.listen(this,"keydown",Oe,this.onTargetKeyDown,!1),F.listen(this,"focus",Oe,this.onTargetGotFocus),F.listen(this,"blur",Oe,this.onTargetLostFocus)}unlistenFromTarget(Oe){F.unlisten(this,"pointerdown",Oe,this.onTargetPointerDown),F.unlisten(this,"keydown",Oe,this.onTargetKeyDown),F.unlisten(this,"focus",Oe,this.onTargetGotFocus),F.unlisten(this,"blur",Oe,this.onTargetLostFocus)}connectedCallback(){super.connectedCallback();const Oe=this.getRootNode().host;null==this.target&&null!=Oe&&(this.target=Oe,null==this.actionTarget&&(this.actionTarget=this.target),this.listenForTarget(this.target))}onTargetKeyDown(Oe){switch(Oe.keyCode){case ee.SPACEBAR:Oe.preventDefault(),this.fireClickEventOnActionTarget();}}async onTargetPointerDown(Oe){Oe===this.lastFiredPointerDownEvent||(this.pointerInitiated=!0,null!=this.timeout&&(clearTimeout(this.timeout),this.timeout=null),this.timeout=setTimeout(()=>{this.pointerInitiated=!1,this.timeout=null},ie.POINTER_INITIATED_DELAY))}fireClickEventOnActionTarget(){if(null!=this.target&&null!=this.actionTarget){this.target.focus();const Oe=new MouseEvent("click");this.actionTarget.dispatchEvent(Oe)}}firePointerDownEventOnTarget(){if(null!=this.target){const Oe=new PointerEvent("pointerdown",{width:-1,height:-1});this.lastFiredPointerDownEvent=Oe,this.target.dispatchEvent(Oe),this.target.focus()}}firePointerUpEventOnTarget(){if(null!=this.target){const Oe=new PointerEvent("pointerup");this.target.dispatchEvent(Oe),this.target.blur()}}async onTargetGotFocus(){this.pointerInitiated||this.firePointerDownEventOnTarget()}async onTargetLostFocus(){this.firePointerUpEventOnTarget()}};ne.POINTER_INITIATED_DELAY=1e3,ne=ie=o([a("focusable-composite")],ne);var ie;let te=class extends U{constructor(){super(...arguments),this.tabindex="0",this.role="button"}static markup(){return`
			<slot></slot>
			<ripple-composite class="ripple" light></ripple-composite>
			<focusable-composite></focusable-composite>
		`}static styles(){return`

		:host-context([center]),
		:host([center]) {
			align-self: center;
			justify-self: center;
		}

		:host {
			user-select: none;
			backface-visibility: hidden;
			transform: translate3d(0,0,0);
			box-sizing: border-box;
			contain: content;
			overflow: hidden;
			display: inline-flex;
			align-items: center;
			justify-content: center;
			text-align: center;
			flex-direction: row;
			position: relative;
			min-height: 46px;
			min-width: 46px;
			width: 200px;
			height: 46px;
			cursor: pointer !important;
			padding: 14px;
			border-radius: var(--box-radius);
			flex-shrink: 0;
			transition: background var(--duration-medium) var(--easing-standard-curve);
		}
		
		::slotted(*) {
			color: var(--color-primary-100) !important;
			font-size: var(--font-size-button) !important;
			line-height: var(--font-size-button) !important;
			font-weight: var(--font-weight-button) !important;
			text-transform: uppercase;
			pointer-events: none;
			cursor: pointer !important;
		}
		
		::slotted(icon-element) {
			fill: var(--color-icon-dark);
		}
		
		.ripple {
			color: var(--color-primary-100);
		}
		
		:host([primary]) {
			background: var(--color-primary-100);
		}
		
		:host([primary]) .ripple {
			color: var(--color-white-70);
		}
		
		:host([primary]:hover) {
			background: var(--color-primary-120) !important;
		}
		
		:host([primary]) ::slotted(*) {
			color: var(--color-primary-text-light) !important;
		}
		
		:host([primary]) ::slotted(icon-element) {
			fill: var(--color-icon-light) !important;
		}
			
		:host([accent]) {
			background: var(--color-accent-100);
		}
		
		:host([accent]) .ripple {
			color: var(--color-white-70);
		}
		
		:host([accent]:hover) {
			background: var(--color-accent-120);
		}
		
		:host([accent]) ::slotted(*) {
			color: var(--color-primary-text-light) !important;
		}
		
		:host([accent]) ::slotted(icon-element) {
			fill: var(--color-icon-light) !important;
		}
			
		:host([dark]) {
			background: var(--color-black-70);
		}
		
		:host([dark]) .ripple {
			color: var(--color-white-70);
		}
		
		:host([dark]:hover) {
			background: var(--color-black-87);
		}
		
		:host([dark]) ::slotted(*) {
			color: var(--color-primary-text-light) !important;
		}
		
		:host([dark]) ::slotted(icon-element) {
			fill: var(--color-icon-light) !important;
		}
			
		:host([light]) {
			background: var(--color-white-100);
		}
		
		:host([light]) .ripple {
			color: var(--color-icon-dark);
		}
		
		:host([light]:hover) {
			background: var(--color-white-87);
		}
		
		:host([light]) ::slotted(*) {
			color: var(--color-primary-text-dark) !important;
		}
		
		:host([light]) ::slotted(icon-element) {
			fill: var(--color-icon-dark) !important;
		}
		
		:host([warning]) {
			background: var(--color-red-100);
		}
		
		:host([warning]:hover) {
			background: var(--color-red-120);
		}
		
		:host([warning]) .ripple {
			color: var(--color-white-70);
		}
		
		:host([warning]) ::slotted(*) {
			color: var(--color-primary-text-light) !important;
		}
		
		:host([warning]) ::slotted(icon-element) {
			fill: var(--color-icon-light) !important;
		}
		
		:host([shadow]) {
			box-shadow: var(--shadow-level1);
		}
		
		:host([shadow]:hover) {
			box-shadow: var(--shadow-level3);
		}
		
		:host(:hover) {
			background: var(--color-black-06);
		}

		:host[disabled] {
			pointer-events: none;
			opacity: .6;
		}
		`}connectedCallback(){super.connectedCallback()}};te=o([a("button-element")],te);let oe=class extends U{constructor(){super(...arguments),this.role="banner"}static markup(){return`
			<hero-element center>
				<icon-element icon="fovea-logo" extreme light></icon-element>
				<h3>Fovea</h3>
				<h5>Let's build a better web. For <strong>everyone.</strong></h5>
				<code-element>
					<pre>npm install @wessberg/fovea</pre>
				</code-element>
				<button-element primary shadow>
					<p>Get started</p>
				</button-element>
			</hero-element>
		`}static styles(){return`
			h3, h5 {
				color: var(--color-primary-text-light);
			}
			
			h3, h5, strong {
				user-select:text;
			}
			
			h3 {
				font-weight: var(--font-weight-bold);
			}
			
			code-element {
				max-width: 392px;
				margin-bottom: var(--distance-regular);
			}
		`}};oe=o([a("home-hero-element")],oe);let re=class extends U{static styles(){return`
			code-element {
				position: relative;
				width: 100%;
				max-width: 369px;
				max-height: inherit;
				box-shadow: var(--shadow-level3);
			}
		`}static markup(){return`
			<code-element><!--
		 --><pre class="keyword">class</pre><!--
		 --><pre> </pre><!--
		 --><pre class="identifier">MyView</pre><!--
		 --><pre> </pre><!--
		 --><pre class="keyword">extends</pre><!--
		 --><pre> </pre><!--
		 --><pre class="identifier">View</pre><!--
		 --><pre> </pre><!--
		 --><pre class="brace">{</pre><!--
		 --><br><pre>  </pre><!--
		 --><pre class="decorator">@prop</pre><!--
		 --><pre> </pre><!--
		 --><pre class="property">name</pre><!--
		 --><pre class="token">:</pre><!--
		 --><pre> </pre><!--
		 --><pre class="keyword">string</pre><!--
		 --><pre class="token">;</pre><!--
		 --><br><pre>  </pre><!--
		 --><pre class="decorator">@prop</pre><!--
		 --><pre> </pre><!--
		 --><pre class="property">media</pre><!--
		 --><pre class="token">:</pre><!--
		 --><pre> </pre><!--
		 --><pre class="type">IMedia</pre><!--
		 --><pre class="token">;</pre><!--
		 --><br><pre>  </pre><!--
		 --><pre class="decorator">@prop</pre><!--
		 --><pre> </pre><!--
		 --><pre class="property">numbers</pre><!--
		 --><pre class="token">:</pre><!--
		 --><pre> </pre><!--
		 --><pre class="keyword">number</pre><!--
		 --><pre class="bracket">[]</pre><!--
		 --><pre class="token">;</pre><!--
		 --><br><pre>  </pre><!--
		 --><pre class="decorator">@prop</pre><!--
		 --><pre> </pre><!--
		 --><pre class="property">myFavoriteColor</pre><!--
		 --><pre class="token">:</pre><!--
		 --><pre> </pre><!--
		 --><pre class="keyword">string</pre><!--
		 --><pre class="token">;</pre><!--
		 --><br><!--
		 --><br><pre>  </pre><!--
		 --><pre class="method">markup</pre><!--
		 --><pre> </pre><!--
		 --><pre class="parenthesis">()</pre><!--
		 --><pre> </pre><!--
		 --><pre class="brace">{</pre><!--
		 --><br><pre>    </pre><!--
		 --><pre class="keyword">return</pre><!--
		 --><pre> </pre><!--
		 --><pre class="token">\`</pre><!--
		 --><br><pre>      </pre><!--
		 --><pre class="token"><</pre><!--
		 --><pre class="tagname">p</pre><!--
		 --><pre class="token">></pre><!--
		 --><pre class="string">Hello </pre><!--
		 --><pre class="token">$</pre><!--
		 --><pre class="brace">{</pre><!--
		 --><pre class="keyword">this</pre><!--
		 --><pre class="token">.</pre><!--
		 --><pre class="property">name</pre><!--
		 --><pre class="brace">}</pre><!--
		 --><pre class="string">!</pre><!--
		 --><pre class="token"><</pre><!--
		 --><pre class="token">/</pre><!--
		 --><pre class="tagname">p</pre><!--
		 --><pre class="token">></pre><!--
		 --><br><pre>      </pre><!--
		 --><pre class="token"><</pre><!--
		 --><pre class="tagname">img</pre><!--
		 --><pre> </pre><!--
		 --><pre class="attribute_name">src=</pre><!--
		 --><pre class="attribute_value">"</pre><!--
		 --><pre class="token">$</pre><!--
		 --><pre class="brace">{</pre><!--
		 --><pre class="keyword">this</pre><!--
		 --><pre class="token">.</pre><!--
		 --><pre class="property">media</pre><!--
		 --><pre class="token">.</pre><!--
		 --><pre class="property">src</pre><!--
		 --><pre class="brace">}</pre><!--
		 --><pre class="attribute_value">"</pre><!--
		 --><pre class="token">/</pre><!--
		 --><pre class="token">></pre><!--
		 --><br><pre>      </pre><!--
		 --><pre class="token"><</pre><!--
		 --><pre class="tagname">span</pre><!--
		 --><pre> </pre><!--
		 --><pre class="attribute_name">foreach=</pre><!--
		 --><pre class="attribute_value">"</pre><!--
		 --><pre class="token">$</pre><!--
		 --><pre class="brace">{</pre><!--
		 --><pre class="keyword">this</pre><!--
		 --><pre class="token">.</pre><!--
		 --><pre class="property">numbers</pre><!--
		 --><pre class="brace">}</pre><!--
		 --><pre class="attribute_value">"</pre><!--
		 --><pre class="token">></pre><!--
		 --><br><pre>        </pre><!--
		 --><pre class="token">$</pre><!--
		 --><pre class="brace">{</pre><!--
		 --><pre class="keyword">this</pre><!--
		 --><pre class="token">.</pre><!--
		 --><pre class="property">numbers</pre><!--
		 --><pre class="bracket">[</pre><!--
		 --><pre class="type">index</pre><!--
		 --><pre class="bracket">]</pre><!--
		 --><pre class="brace">}</pre><!--
		 --><br><pre>      </pre><!--
		 --><pre class="token"><</pre><!--
		 --><pre class="token">/</pre><!--
		 --><pre class="tagname">span</pre><!--
		 --><pre class="token">></pre><!--
		 --><br><pre>    </pre><!--
		 --><pre class="token">\`</pre><!--
		 --><pre class="token">;</pre><!--
		 --><br><pre>  </pre><!--
		 --><pre class="brace">}</pre><!--
		 --><br><!--
		 --><br><pre>  </pre><!--
		 --><pre class="method">styles</pre><!--
		 --><pre> </pre><!--
		 --><pre class="parenthesis">()</pre><!--
		 --><pre> </pre><!--
		 --><pre class="brace">{</pre><!--
		 --><br><pre>    </pre><!--
		 --><pre class="keyword">return</pre><!--
		 --><pre> </pre><!--
		 --><pre class="token">\`</pre><!--
		 --><br><pre>      </pre><!--
		 --><pre class="css_selector_name">p</pre><!--
		 --><pre> </pre><!--
		 --><pre class="brace">{</pre><!--
		 --><br><pre>        </pre><!--
		 --><pre class="css_property_name">color</pre><!--
		 --><pre class="token">:</pre><!--
		 --><pre> </pre><!--
		 --><pre class="token">$</pre><!--
		 --><pre class="brace">{</pre><!--
		 --><pre class="keyword">this</pre><!--
		 --><pre class="token">.</pre><!--
		 --><pre class="property">myFavoriteColor</pre><!--
		 --><pre class="brace">}</pre><!--
		 --><pre class="token">;</pre><!--
		 --><br><pre>        </pre><!--
		 --><pre class="css_property_name">font-size</pre><!--
		 --><pre class="token">:</pre><!--
		 --><pre> </pre><!--
		 --><pre class="token">$</pre><!--
		 --><pre class="brace">{</pre><!--
		 --><pre class="identifier">Text</pre><!--
		 --><pre class="token">.</pre><!--
		 --><pre class="property">DEFAULT_SIZE</pre><!--
		 --><pre class="brace">}</pre><!--
		 --><pre class="token">px</pre><!--
		 --><pre class="token">;</pre><!--
		 --><br><pre>      </pre><!--
		 --><pre class="brace">}</pre><!--
		 --><br><pre>    </pre><!--
		 --><pre class="token">\`</pre><!--
		 --><pre class="token">;</pre><!--
		 --><br><pre>  </pre><!--
		 --><pre class="brace">}</pre><!--
		 --><br><!--
		 --><pre class="brace">}</pre><!--
	--></code-element>
		`}};re=o([a("code-example-element")],re);let de=class extends U{static styles(){return`
			:host {
				position: relative;
				text-align: center;
				width: 100%;
				max-width: var(--width-frame-max);
				justify-content: center;
				align-content: center;
				display: inline-flex;
				flex-direction: column;
				margin: 0 auto;
			}
			
			card-element > p {
				margin: 20px 0;
			}
			
			card-element > button-element {
				width: 120px;
			}
			
			card-element > p,
			card-element > strong,
			card-element > h6 {
				user-select: text;
			}
			
			card-element,
			code-example-element {
				max-height: 450px;
				margin: var(--distance-minimum) auto;
				width: 100%;
			}
			
			@media screen and (min-width: 700px) {
			
				:host {
					flex-direction: row;
				}
				
				card-element,
				code-example-element {
					margin: var(--distance-minimum) 0;
				}
			}
		`}static markup(){return`
			<code-example-element></code-example-element>
			<card-element>
				<h6>Data-binding has never been easier</h6>
				<p>
					Enjoy binding your data to the DOM will full autocompletion support from your editor. Bindings persist and change immediately when your model changes.
				</p>
				<strong>You can bind to anything</strong>
				<p>
					Not only can you bind complex data to elements and text nodes. Fovea comes with groundbreaking support for binding data to the CSS styles of individual view component instances. No serializing is going on. Instead, the values or references are passed directly. It just works!
				</p>
				<button-element>
					<p>Learn more</p>
				</button-element>
			</card-element>
		`}};de=o([a("data-binding-example-element")],de);let ae=class extends U{static styles(){return`
			code-element {
				max-height: inherit;
				max-width: inherit;
				box-shadow: var(--shadow-level3);
				text-align: left;
			}
		`}static markup(){return`
			<code-element><!--
		 --><pre class="token"><</pre><!--
		 --><pre class="tagname">img</pre><!--
		 --><pre> </pre><!--
		 --><pre class="attribute_name">id=</pre><!--
		 --><pre class="attribute_value">"placeholderImage"</pre><!--
		 --><pre> </pre><!--
		 --><pre class="attribute_name">src=</pre><!--
		 --><pre class="attribute_value">"</pre><!--
		 --><pre class="token">$</pre><!--
		 --><pre class="brace">{</pre><!--
		 --><pre class="keyword">this</pre><!--
		 --><pre class="token">.</pre><!--
		 --><pre class="property">placeholderMedia</pre><!--
		 --><pre class="token">.</pre><!--
		 --><pre class="property">src</pre><!--
		 --><pre class="brace">}</pre><!--
		 --><pre class="attribute_value">"</pre><!--
		 --><pre> </pre><!--
		 --><pre class="attribute_name">onclick=</pre><!--
		 --><pre class="attribute_value">"</pre><!--
		 --><pre class="token">$</pre><!--
		 --><pre class="brace">{</pre><!--
		 --><pre class="keyword">this</pre><!--
		 --><pre class="token">.</pre><!--
		 --><pre class="property">onPlaceholderTapped</pre><!--
		 --><pre class="brace">}</pre><!--
		 --><pre class="attribute_value">"</pre><!--
		 --><pre class="token">/</pre><!--
		 --><pre class="token">></pre><!--
		 --><br><!--
		 --><pre class="token"><</pre><!--
		 --><pre class="tagname">img</pre><!--
		 --><pre> </pre><!--
		 --><pre class="attribute_name">alt=</pre><!--
		 --><pre class="attribute_value">"placeholderImage"</pre><!--
		 --><pre class="token">$</pre><!--
		 --><pre class="brace">{</pre><!--
		 --><pre class="keyword">this</pre><!--
		 --><pre class="token">.</pre><!--
		 --><pre class="property">currentMedia</pre><!--
		 --><pre class="token">.</pre><!--
		 --><pre class="property">description</pre><!--
		 --><pre class="brace">}</pre><!--
		 --><pre class="attribute_value">"</pre><!--
		 --><pre> </pre><!--
		 --><pre class="attribute_name">id=</pre><!--
		 --><pre class="attribute_value">"mainImage"</pre><!--
		 --><pre class="token">/</pre><!--
		 --><pre class="token">></pre><!--
	--></code-element>
		`}};ae=o([a("precompile-code-example-element")],ae);let le=class extends U{static styles(){return`
			:host {
				text-align: center;
				width: 100%;
				max-width: 830px;
				justify-content: center;
				align-content: center;
				align-self: center;
				justify-self: center;
				position: relative;
				display: inline-flex;
				flex-direction: row;
				margin: 0;
			}
			
			icon-element {
				margin: auto;		
			}
			
			precompile-code-example-element {
				max-height: 150px;
				margin: auto;
				width: calc(100% - var(--width-icon-larger) - var(--distance-regular) );
			}

		`}static markup(){return`
			<icon-element icon="fovea-1" larger light></icon-element>
			<precompile-code-example-element center></precompile-code-example-element>
		`}};le=o([a("precompile-example-element")],le);let se=class extends U{static styles(){return`
			code-element {
				max-height: inherit;
				max-width: inherit;
				box-shadow: var(--shadow-level3);
				text-align: left;
			}
		`}static markup(){return`
			<code-element><!--
		 --><pre class="keyword">const</pre><!--
		 --><pre> </pre><!--
		 --><pre class="variable">_0</pre><!--
		 --><pre> </pre><!--
		 --><pre class="token">=</pre><!--
		 --><pre> </pre><!--
		 --><pre class="function">__createElementHelper</pre><!--
		 --><pre class="parenthesis">(</pre><!--
		 --><pre class="string">"img"</pre><!--
		 --><pre class="parenthesis">)</pre><!--
		 --><pre class="token">;</pre><!--
		 --><pre class="function">__addBindingHelper</pre><!--
		 --><pre class="parenthesis">(</pre><!--
		 --><pre class="keyword">this</pre><!--
		 --><pre class="token">,</pre><!--
		 --><pre> </pre><!--
		 --><pre class="variable">_0</pre><!--
		 --><pre class="token">,</pre><!--
		 --><pre> </pre><!--
		 --><pre class="string">"placeholderMedia"</pre><!--
		 --><pre class="token">,</pre><!--
		 --><pre> </pre><!--
		 --><pre class="bracket">[</pre><!--
		 --><pre class="string">"src"</pre><!--
		 --><pre class="bracket">]</pre><!--
		 --><pre class="token">,</pre><!--
		 --><pre> </pre><!--
		 --><pre class="string">"src"</pre><!--
		 --><pre class="parenthesis">)</pre><!--
		 --><pre class="token">,</pre><!--
		 --><br><!--
		 --><pre class="keyword">this</pre><!--
		 --><pre class="token">.</pre><!--
		 --><pre class="property">placeholderMedia</pre><!--
		 --><pre> </pre><!--
		 --><pre class="token">!==</pre><!--
		 --><pre> </pre><!--
		 --><pre class="keyword">void</pre><!--
		 --><pre> </pre><!--
		 --><pre class="number">0</pre><!--
		 --><pre> </pre><!--
		 --><pre class="token">&&</pre><!--
		 --><pre> </pre><!--
		 --><pre class="keyword">this</pre><!--
		 --><pre class="token">.</pre><!--
		 --><pre class="property">placeholderMedia</pre><!--
		 --><pre class="token">.</pre><!--
		 --><pre class="property">src</pre><!--
		 --><pre> </pre><!--
		 --><pre class="token">!==</pre><!--
		 --><pre> </pre><!--
		 --><pre class="keyword">void</pre><!--
		 --><pre> </pre><!--
		 --><pre class="number">0</pre><!--
		 --><pre class="comment">... // And so on</pre><!--
	--></code-element>
		`}};se=o([a("postcompile-code-example-element")],se);let ue=class extends U{static styles(){return`
			:host {
				text-align: center;
				width: 100%;
				max-width: var(--width-frame-max);
				justify-content: center;
				align-content: center;
				align-self: center;
				justify-self: center;
				position: relative;
				display: inline-flex;
				flex-direction: row;
				margin: 0;
			}
			
			icon-element {
				margin: auto;		
			}
			
			postcompile-code-example-element {
				max-height: 150px;
				margin: auto;
				width: calc(100% - var(--width-icon-larger) - var(--distance-regular) );
			}

		`}static markup(){return`
			<icon-element icon="fovea-2" larger light></icon-element>
			<postcompile-code-example-element center></postcompile-code-example-element>
		`}};ue=o([a("postcompile-example-element")],ue);let fe=class extends U{static styles(){return`
			:host {
				display: flex;
				align-content: center;
				justify-content: center;
				flex-direction: row;
				height: var(--height-icon-larger);
			}
			
			h3 {
				margin: 0;
				line-height: 1.2;
				padding: 0 10px;
			}
		`}static markup(){return`
			<icon-element id="fovea" icon="fovea-logo" larger primary></icon-element>
			<h3>+</h3>
			<icon-element id="rollup" icon="rollup-logo" larger></icon-element>
			<icon-element id="webpack" icon="webpack-logo" larger></icon-element>
			<h3>=</h3>
			<icon-element id="heart" icon="heart-fill" larger warning></icon-element>
		`}};fe=o([a("fovea-rollup-webpack-element")],fe);let ce=class extends U{constructor(){super(...arguments),this.role="complementary"}static styles(){return`
			:host {
				text-align: center;
				width: 100%;
				justify-content: center;
				align-content: center;
				position: relative;
				display: flex;
				flex-direction: column;
				margin: 0;
			}
			
			#row1 {
				flex-direction: column;
			}
			
			#row2 {
				flex-direction: column-reverse;
			}
			
			#row1, #row2 {
				display: inline-flex;
				justify-content: center;
				align-content: center;
				max-width: var(--width-frame-max);
				width: 100%;
				margin: 0 auto;
			}
			
			#row2 > icon-element {
				height: var(--height-icon-larger);
			}
			
			#row1 > fovea-rollup-webpack-element,
			#row2 > icon-element {
				align-self: center;
				margin-top: 15px;
			}
			
			#row1 > fovea-rollup-webpack-element,
			#row2 > icon-element {
				flex-grow: 1;
			}
			
			#row1,
			#row2 {
				transform: translate3d(0, -60px, 0);
				margin-top: 20px;
				margin-bottom: 20px;
			}
			
			#row1 > fovea-rollup-webpack-element {
				padding-right: var(--distance-minimum);
			}
			
			card-element > button-element {
				width: 120px;
			}
			
			card-element > p,
			card-element > h6,
			a {
				user-select: text;
			}
			
			card-element {
				max-height: 350px;
				margin: var(--distance-minimum) auto;
			}
			
			
			
			@media screen and (min-width: 700px) {
				
				card-element {
					margin: var(--distance-minimum);
				}
				
				#row1, #row2 {
					flex-direction: row;
					margin-top: 0;
					margin-bottom: 0;
				}
				
				#row1 > fovea-rollup-webpack-element,
				#row2 > icon-element {
					margin-top: 0;
				}
			}
		`}static markup(){return`
			<section id="row1">
				<card-element>
						<h6>Works with your existing build tools</h6>
						<p>
							Fovea won’t ask you to change your tools, habits or the way you write code. Instead, Fovea is a simple plugin for your favorite bundler such as <a href="https://rollupjs.org/" target="_blank">rollup</a> or <a href="https://webpack.js.org/" target="_blank">webpack</a>.
						</p>
						<button-element>
							<p>Learn more</p>
						</button-element>
				</card-element>
				<fovea-rollup-webpack-element></fovea-rollup-webpack-element>
			</section>
			
			<section id="row2">
				<icon-element icon="typescript-logo" extreme></icon-element>
				<card-element>
						<h6>Built with TypeScript</h6>
						<p>
							Fovea is built with TypeScript. Whether or not you annotate your code, you will have a great development experience!
						</p>
						<button-element>
							<p>Learn more</p>
						</button-element>
				</card-element>
			</section>
		`}};ce=o([a("tools-element")],ce);let pe=class extends U{constructor(){super(...arguments),this.role="complementary"}static styles(){return`
			:host {
				background: var(--color-primary-100);
				text-align: center;
				width: 100%;
				justify-content: center;
				align-content: center;
				position: relative;
				display: inline-flex;
				flex-direction: column;
				margin: 0;
				padding: var(--distance-minimum) var(--distance-minimum) 100px var(--distance-minimum);
			}
			
			h4, h5 {
				padding-top: var(--distance-regular);
				color: var(--color-primary-text-light);
			}
			
			
		`}static markup(){return`
			<h4>Summary</h4>
			<data-binding-example-element></data-binding-example-element>
			<h5>Fovea takes this:</h5>
			<precompile-example-element></precompile-example-element>
			<h5>And compiles it into this:</h5>
			<postcompile-example-element></postcompile-example-element>
		`}};pe=o([a("summary-element")],pe);let ge=class extends U{constructor(){super(...arguments),this.role="contentinfo"}static styles(){return`
			
			:host([primary]) {
				background: var(--color-primary-100);
			}
			
			:host([accent]) {
				background: var(--color-accent-100);
			}
			
			:host([dark]) {
				background: var(--color-black-70);
			}
			
			:host([light]) {
				background: var(--color-white-87);
			}

			:host {
				box-sizing: border-box;
				position: relative;
				display: flex;
				width: 100%;
				z-index: 997;
			}
			
			#wrapper {
				position: relative;
				display: inline-flex;
				padding: var(--distance-regular);
				flex-wrap: wrap;
				margin: auto;
				flex-direction: row;
				align-content: flex-start;
				justify-content: flex-start;
				width: 100%;
				
			}
			
			.row {
				display: flex;
				flex-direction: column;
				align-content: flex-start;
				justify-content: flex-start;
				margin: var(--distance-minimum);
			}
			
			.rowSlot::slotted(h1),
			.rowSlot::slotted(h2),
			.rowSlot::slotted(h3),
			.rowSlot::slotted(h4),
			.rowSlot::slotted(h5),
			.rowSlot::slotted(h6) {
				text-transform: uppercase !important;
				color: var(--color-white-70) !important;
				margin: 0 0 8px 0 !important;
				line-height: 1 !important;
				order: 0;
			}
			
			#logoSlot::slotted(*) {
				margin: auto;
			}
			
			.rowSlot::slotted(*) {
				font-size: var(--font-size-caption) !important;
			}
			
			.rowSlot::slotted(a) {
				color: var(--color-white-100) !important;
			}
			
			.rowSlot::slotted(a:hover),
			.rowSlot::slotted(a:focus) {
				color: var(--color-primary-100) !important;
			}
			
			#logoSlot::slotted(*) {
					margin: auto 0 auto var(--distance-regular);
				}
			
			@media screen and (min-width: 677px) {
				#wrapper {
					align-content: space-around;
					justify-content: space-around;
				}
			}
			
		`}static markup(){return`
			<slot id="logoSlot" name="logo"></slot>
			<div id="wrapper">
				<section id="row1" class="row">
					<slot id="row1Slot" class="rowSlot" name="row1"></slot>
				</section>
				<section id="row2" class="row">
					<slot id="row2Slot" class="rowSlot" name="row2"></slot>
				</section>
				<section id="row3" class="row">
					<slot id="row3Slot" class="rowSlot" name="row3"></slot>
				</section>	
				<section id="row4" class="row">
					<slot id="row4Slot" class="rowSlot" name="row4"></slot>
				</section>
				<section id="row5" class="row">
					<slot id="row5Slot" class="rowSlot" name="row5"></slot>
				</section>
				
			</div>
		`}};ge=o([a("app-footer-element")],ge);let me=class extends U{constructor(){super(...arguments),this.role="contentinfo"}static styles(){return``}static markup(){return`
			<app-footer-element dark>
					<icon-element icon="fovea-logo" slot="logo" larger light></icon-element>
					<h3 slot="row1">Getting started</h3>
					<a href="/" target="_self" slot="row1">Your first component</a>
					<a href="/" target="_self" slot="row1">Your first app</a>
					<a href="/" target="_self" slot="row1">Tool integration</a>
					
					<h3 slot="row2">Help</h3>
					<a href="/" target="_self" slot="row2">Report issue</a>
					<a href="/" target="_self" slot="row2">Stack overflow</a>
					<a href="/" target="_self" slot="row2">License</a>
					
					<h3 slot="row3">About</h3>
					<a href="/" target="_self" slot="row3">Author</a>
					<a href="/" target="_self" slot="row3">Motivation</a>
					<a href="/" target="_self" slot="row3">Benchmarks</a>
					
					<h3 slot="row4">Resources</h3>
					<a href="/" target="_self" slot="row4">Learn</a>
					<a href="/" target="_self" slot="row4">Advanced</a>
					<a href="/" target="_self" slot="row4">FAQ</a>
					
					<h3 slot="row5">News</h3>
					<a href="/" target="_self" slot="row5">Releases</a>
					<a href="/" target="_self" slot="row5">Blog</a>
					<a href="/" target="_self" slot="row5">Press</a>
					
					<h3 slot="row6">Links</h3>
					<a href="/" target="_self" slot="row6">Github</a>
					<a href="/" target="_self" slot="row6">NPM</a>
					<a href="/" target="_self" slot="row6">Twitter</a>
					
      </app-footer-element>
		`}};me=o([a("fovea-footer-element")],me);let he=class extends X{constructor(){super(...arguments),this.role="main"}static styles(){return super.styles()+`
			:host {
				height: calc(100vh - var(--app-bar-portrait-height-desktop));
				top: var(--app-bar-portrait-height-desktop);
				margin-bottom: var(--app-bar-portrait-height-desktop);
				
			}
		`}};he=o([a("page-element")],he);let Ee=class extends he{static markup(){return`
			<home-hero-element></home-hero-element>
			<highlights-element></highlights-element>
			<summary-element></summary-element>
			<section id="bottom">
				<material-triangles-element accent></material-triangles-element>
				<tools-element></tools-element>
				<fovea-footer-element></fovea-footer-element>
			</section>
		`}static styles(){return super.styles()+`
			highlights-element {
				transform: translate3d(0, -40px, 0);
			}
			
			material-triangles-element {
				top: auto;
				bottom: 0;
			}
			
			#bottom {
				position: relative;
			}
		`}};Ee=o([a("home-page-element")],Ee);let Ie=class extends U{constructor(){super(...arguments),this.role="application"}static styles(){return`
			:host {
				transform: translate3d(0,0,0);
				backface-visibility: hidden;
				box-sizing: border-box;
				contain: content;
				position: relative;
				display: block;
				width: 100%;
				height: 100%;
			}
		`}};Ie=o([a("frame-element")],Ie),n.HomeFrame=class extends Ie{static markup(){return`
			<fovea-app-bar-element></fovea-app-bar-element>
			<home-page-element></home-page-element>
		`}},n.HomeFrame=o([a("home-frame-element")],n.HomeFrame),l.addIcons([v,s,u,f,p,g,m,E,I,A,w,O]),H.block("dragstart"),L.isMobile&&H.block("contextmenu")})(this.fovea=this.fovea||{});
